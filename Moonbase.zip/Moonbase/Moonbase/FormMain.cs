﻿/*
 Jeremy Gurzynski
 CSC202
 jgurzynski85952@uat.edu
 Week 2 MoonBase Alpha II Assignment
 */

//Lines 9 - 18 are used for various functionalities of C#
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Name of our file
namespace Moonbase
{
    //Declares our Moonbase that inherits from form
    public partial class Moonbase : Form
    {
        
        //Constructor for our form
        public Moonbase()
        {
            //Initializes control objects, properties, and adds to proper control collections.
            InitializeComponent();
        }
        //Log File Function with the location string variable
        private void logLocation(string location) 
        {
            //This is for collecting the current date and time with the location
            string logMessage = $"{DateTime.Now}: Moved to {location}";
            //This is where the information will be logged
            string logFile = "locationLog.txt"; 
            //StreamWriter is used for writing to the log files
            using (StreamWriter lw = File.AppendText(logFile)) 
            {
                //Function for writing the lines
                lw.WriteLine(logMessage);
            }


        }
        //Function for each area
        private void centralControlRoom() 
        {
            //Setting background image for the area
            BackgroundImage = Image.FromFile("ControlRoom.jpg");
            // Lines 55 - 61 are for hiding and showing the groupboxes of room name, description and the buttons.
            GBcenconroom.Show();
            GBbackbtn.Hide();
            GBpernav.Show();
            GBopsroom.Hide();
            GBcomroom.Hide();
            GBeng.Hide();
            GBsecroom.Hide();
            //Call log location function with the name of the room for logging
            logLocation("Central Control Room");
        }
        //Function for Operations
        private void operationsRoom() 
        {
            //Setting background image for the area
            BackgroundImage = Image.FromFile("opsroom.jpg");
            //Lines 71 - 77 are for hiding and showing the groupboxes of room name, description and the buttons.
            GBopsroom.Show();
            GBcenconroom.Hide();
            GBbackbtn.Show();
            GBpernav.Hide();
            GBeng.Hide();
            GBcomroom.Hide();
            GBsecroom.Hide();
            //Call log location function with the name of the room for logging
            logLocation("Operations Room");
        }
        //Function for Security
        private void securityRoom() 
        {
            //Setting background image for the area
            BackgroundImage = Image.FromFile("secroom.jpg");
            //Lines 87 - 93 are for hiding and showing the groupboxes of room name, description and the buttons.
            GBcenconroom.Hide();
            GBcomroom.Hide();
            GBbackbtn.Show();
            GBpernav.Hide();
            GBopsroom.Hide();
            GBeng.Hide();
            GBsecroom.Show();
            //Call log location function with the name of the room for logging
            logLocation("Security Room");
        }
        //Function for Communications
        private void communicationsRoom() 
        {
            //Setting background image for the area
            BackgroundImage = Image.FromFile("comroom.jpg");
            //Lines 103 - 109 are for hiding and showing the groupboxes of room name, description and the buttons.
            GBcenconroom.Hide();
            GBcomroom.Show();
            GBbackbtn.Show();
            GBpernav.Hide();
            GBeng.Hide();
            GBopsroom.Hide();
            GBsecroom.Hide();
            //Call log location function with the name of the room for logging
            logLocation("Communications Room");
        }
        //Function for Engineering
        private void engineeringRoom()
        {
            //Setting background image for the area
            BackgroundImage = Image.FromFile("engRoom.jpg");
            //Lines 119 - 125 are for hiding and showing the groupboxes of room name, description and the buttons.
            GBcenconroom.Hide();
            GBcomroom.Hide();
            GBbackbtn.Show();
            GBpernav.Hide();
            GBopsroom.Hide();
            GBeng.Show();
            GBsecroom.Hide();
            //Call log location function with the name of the room for logging
            logLocation("Engineering Room");
        }
        //And finally the buttons that activate each function
        //Function called when button is pressed.
        private void BTNops_Click(object sender, EventArgs e)
        {
            //Message box will appear once button is selected.
            MessageBox.Show("Going to: Operations Station.");
            //Calling function for the area
            operationsRoom();
            
        }
        //Function called when button is pressed.
        private void BTNeng_Click(object sender, EventArgs e)
        {
            //Message box will appear once button is selected.
            MessageBox.Show("Going to: Engineering Station.");
            //Calling function for the area
            engineeringRoom();
        }
        //Function called when button is pressed.
        private void BTNres_Click(object sender, EventArgs e)
        {
            //Message box will appear once button is selected.
            MessageBox.Show("Going to: Security Station.");
            //Calling function for the area
            securityRoom();
        }
        //Function called when button is pressed.
        private void BTNcoms_Click(object sender, EventArgs e)
        {
            //Message box will appear once button is selected.
            MessageBox.Show("Going to: Communications Station.");
            communicationsRoom();
        }
        //Function called when button is clicked
        private void BTNcencon_Click(object sender, EventArgs e)
        {
            //Message box will appear once button is clicked
            MessageBox.Show("Going back to Central Control.");
            //Calling function for the area
            centralControlRoom();
        }
    }
}
